/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-pages-browser)/./src/app/components/Header/HeaderTop/HeaderTop.jsx":
/*!***********************************************************!*\
  !*** ./src/app/components/Header/HeaderTop/HeaderTop.jsx ***!
  \***********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {



;
    // Wrapped in an IIFE to avoid polluting the global scope
    ;
    (function () {
        var _a, _b;
        // Legacy CSS implementations will `eval` browser code in a Node.js context
        // to extract CSS. For backwards compatibility, we need to check we're in a
        // browser context before continuing.
        if (typeof self !== 'undefined' &&
            // AMP / No-JS mode does not inject these helpers:
            '$RefreshHelpers$' in self) {
            // @ts-ignore __webpack_module__ is global
            var currentExports = module.exports;
            // @ts-ignore __webpack_module__ is global
            var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
            // This cannot happen in MainTemplate because the exports mismatch between
            // templating and execution.
            self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
            // A module can be accepted automatically based on its exports, e.g. when
            // it is a Refresh Boundary.
            if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
                // Save the previous exports on update so we can compare the boundary
                // signatures.
                module.hot.dispose(function (data) {
                    data.prevExports = currentExports;
                });
                // Unconditionally accept an update to this module, we'll check if it's
                // still a Refresh Boundary later.
                // @ts-ignore importMeta is replaced in the loader
                module.hot.accept();
                // This field is set when the previous version of this module was a
                // Refresh Boundary, letting us know we need to check for invalidation or
                // enqueue an update.
                if (prevExports !== null) {
                    // A boundary can become ineligible if its exports are incompatible
                    // with the previous exports.
                    //
                    // For example, if you add/remove/change exports, we'll want to
                    // re-execute the importing modules, and force those components to
                    // re-render. Similarly, if you convert a class component to a
                    // function, we want to invalidate the boundary.
                    if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                        module.hot.invalidate();
                    }
                    else {
                        self.$RefreshHelpers$.scheduleUpdate();
                    }
                }
            }
            else {
                // Since we just executed the code for the module, it's possible that the
                // new exports made it ineligible for being a boundary.
                // We only care about the case when we were _previously_ a boundary,
                // because we already accepted this update (accidental side effect).
                var isNoLongerABoundary = prevExports !== null;
                if (isNoLongerABoundary) {
                    module.hot.invalidate();
                }
            }
        }
    })();


/***/ }),

/***/ "(app-pages-browser)/./src/app/pages/Home/page.jsx":
/*!*************************************!*\
  !*** ./src/app/pages/Home/page.jsx ***!
  \*************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval(__webpack_require__.ts("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"(app-pages-browser)/./node_modules/next/dist/compiled/react/jsx-dev-runtime.js\");\n/* harmony import */ var _app_components_Header_HeaderMiddle_HeaderMiddle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/app/components/Header/HeaderMiddle/HeaderMiddle */ \"(app-pages-browser)/./src/app/components/Header/HeaderMiddle/HeaderMiddle.jsx\");\n/* harmony import */ var _app_components_Header_HeaderTop_HeaderTop__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/app/components/Header/HeaderTop/HeaderTop */ \"(app-pages-browser)/./src/app/components/Header/HeaderTop/HeaderTop.jsx\");\n/* harmony import */ var _app_components_Header_HeaderTop_HeaderTop__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_app_components_Header_HeaderTop_HeaderTop__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _app_components_Header_NavBar_Navbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/app/components/Header/NavBar/Navbar */ \"(app-pages-browser)/./src/app/components/Header/NavBar/Navbar.jsx\");\n/* harmony import */ var _app_sections_Herosec_HeroSec__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/app/sections/Herosec/HeroSec */ \"(app-pages-browser)/./src/app/sections/Herosec/HeroSec.jsx\");\n/* harmony import */ var _app_sections_FeaturedProducts_Products__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/app/sections/FeaturedProducts/Products */ \"(app-pages-browser)/./src/app/sections/FeaturedProducts/Products.jsx\");\n/* harmony import */ var _app_sections_ProductsUpdate_ProductsUpdate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @/app/sections/ProductsUpdate/ProductsUpdate */ \"(app-pages-browser)/./src/app/sections/ProductsUpdate/ProductsUpdate.jsx\");\n/* harmony import */ var _app_sections_Hero_Hero__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/app/sections/Hero/Hero */ \"(app-pages-browser)/./src/app/sections/Hero/Hero.jsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ \"(app-pages-browser)/./node_modules/next/dist/compiled/react/index.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);\n/* harmony import */ var _app_sections_Reviews_Reviews__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @/app/sections/Reviews/Reviews */ \"(app-pages-browser)/./src/app/sections/Reviews/Reviews.jsx\");\n/* harmony import */ var _app_sections_BestOffer_BestOfferCard__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @/app/sections/BestOffer/BestOfferCard */ \"(app-pages-browser)/./src/app/sections/BestOffer/BestOfferCard.jsx\");\n/* harmony import */ var _app_sections_ThreeCard_Card__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @/app/sections/ThreeCard/Card */ \"(app-pages-browser)/./src/app/sections/ThreeCard/Card.jsx\");\n/* harmony import */ var _app_sections_TopCatagory_CarouselComponent__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @/app/sections/TopCatagory/CarouselComponent */ \"(app-pages-browser)/./src/app/sections/TopCatagory/CarouselComponent.jsx\");\n/* harmony import */ var _app_sections_FollowUs_FollowUS__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @/app/sections/FollowUs/FollowUS */ \"(app-pages-browser)/./src/app/sections/FollowUs/FollowUS.jsx\");\n/* harmony import */ var _app_components_Footer_Footer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @/app/components/Footer/Footer */ \"(app-pages-browser)/./src/app/components/Footer/Footer.jsx\");\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nconst HomePage = ()=>{\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_app_sections_Herosec_HeroSec__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                fileName: \"F:\\\\Abdul Qadir\\\\Capstone Project Two\\\\capstone-final\\\\src\\\\app\\\\pages\\\\Home\\\\page.jsx\",\n                lineNumber: 27,\n                columnNumber: 10\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_app_sections_FeaturedProducts_Products__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {}, void 0, false, {\n                fileName: \"F:\\\\Abdul Qadir\\\\Capstone Project Two\\\\capstone-final\\\\src\\\\app\\\\pages\\\\Home\\\\page.jsx\",\n                lineNumber: 30,\n                columnNumber: 10\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_app_sections_ProductsUpdate_ProductsUpdate__WEBPACK_IMPORTED_MODULE_6__[\"default\"], {}, void 0, false, {\n                fileName: \"F:\\\\Abdul Qadir\\\\Capstone Project Two\\\\capstone-final\\\\src\\\\app\\\\pages\\\\Home\\\\page.jsx\",\n                lineNumber: 31,\n                columnNumber: 10\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_app_sections_Reviews_Reviews__WEBPACK_IMPORTED_MODULE_9__[\"default\"], {}, void 0, false, {\n                fileName: \"F:\\\\Abdul Qadir\\\\Capstone Project Two\\\\capstone-final\\\\src\\\\app\\\\pages\\\\Home\\\\page.jsx\",\n                lineNumber: 32,\n                columnNumber: 10\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_app_sections_BestOffer_BestOfferCard__WEBPACK_IMPORTED_MODULE_10__[\"default\"], {}, void 0, false, {\n                fileName: \"F:\\\\Abdul Qadir\\\\Capstone Project Two\\\\capstone-final\\\\src\\\\app\\\\pages\\\\Home\\\\page.jsx\",\n                lineNumber: 33,\n                columnNumber: 10\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_app_sections_FollowUs_FollowUS__WEBPACK_IMPORTED_MODULE_13__[\"default\"], {}, void 0, false, {\n                fileName: \"F:\\\\Abdul Qadir\\\\Capstone Project Two\\\\capstone-final\\\\src\\\\app\\\\pages\\\\Home\\\\page.jsx\",\n                lineNumber: 34,\n                columnNumber: 10\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_app_sections_TopCatagory_CarouselComponent__WEBPACK_IMPORTED_MODULE_12__[\"default\"], {}, void 0, false, {\n                fileName: \"F:\\\\Abdul Qadir\\\\Capstone Project Two\\\\capstone-final\\\\src\\\\app\\\\pages\\\\Home\\\\page.jsx\",\n                lineNumber: 36,\n                columnNumber: 8\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"F:\\\\Abdul Qadir\\\\Capstone Project Two\\\\capstone-final\\\\src\\\\app\\\\pages\\\\Home\\\\page.jsx\",\n        lineNumber: 23,\n        columnNumber: 5\n    }, undefined);\n};\n_c = HomePage;\n/* harmony default export */ __webpack_exports__[\"default\"] = (HomePage);\nvar _c;\n$RefreshReg$(_c, \"HomePage\");\n\n\n;\n    // Wrapped in an IIFE to avoid polluting the global scope\n    ;\n    (function () {\n        var _a, _b;\n        // Legacy CSS implementations will `eval` browser code in a Node.js context\n        // to extract CSS. For backwards compatibility, we need to check we're in a\n        // browser context before continuing.\n        if (typeof self !== 'undefined' &&\n            // AMP / No-JS mode does not inject these helpers:\n            '$RefreshHelpers$' in self) {\n            // @ts-ignore __webpack_module__ is global\n            var currentExports = module.exports;\n            // @ts-ignore __webpack_module__ is global\n            var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;\n            // This cannot happen in MainTemplate because the exports mismatch between\n            // templating and execution.\n            self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);\n            // A module can be accepted automatically based on its exports, e.g. when\n            // it is a Refresh Boundary.\n            if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {\n                // Save the previous exports on update so we can compare the boundary\n                // signatures.\n                module.hot.dispose(function (data) {\n                    data.prevExports = currentExports;\n                });\n                // Unconditionally accept an update to this module, we'll check if it's\n                // still a Refresh Boundary later.\n                // @ts-ignore importMeta is replaced in the loader\n                module.hot.accept();\n                // This field is set when the previous version of this module was a\n                // Refresh Boundary, letting us know we need to check for invalidation or\n                // enqueue an update.\n                if (prevExports !== null) {\n                    // A boundary can become ineligible if its exports are incompatible\n                    // with the previous exports.\n                    //\n                    // For example, if you add/remove/change exports, we'll want to\n                    // re-execute the importing modules, and force those components to\n                    // re-render. Similarly, if you convert a class component to a\n                    // function, we want to invalidate the boundary.\n                    if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {\n                        module.hot.invalidate();\n                    }\n                    else {\n                        self.$RefreshHelpers$.scheduleUpdate();\n                    }\n                }\n            }\n            else {\n                // Since we just executed the code for the module, it's possible that the\n                // new exports made it ineligible for being a boundary.\n                // We only care about the case when we were _previously_ a boundary,\n                // because we already accepted this update (accidental side effect).\n                var isNoLongerABoundary = prevExports !== null;\n                if (isNoLongerABoundary) {\n                    module.hot.invalidate();\n                }\n            }\n        }\n    })();\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL3NyYy9hcHAvcGFnZXMvSG9tZS9wYWdlLmpzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQzRFO0FBQ1Q7QUFDVDtBQUNOO0FBQ2tCO0FBQ0c7QUFFdkI7QUFDekI7QUFDMkI7QUFDYztBQUNsQjtBQUM2QjtBQUN0QjtBQUNKO0FBS25ELE1BQU1jLFdBQVc7SUFDZixxQkFDRSw4REFBQ0M7OzBCQUlJLDhEQUFDWixxRUFBT0E7Ozs7OzBCQUdSLDhEQUFDQywrRUFBZUE7Ozs7OzBCQUNoQiw4REFBQ0MsbUZBQWNBOzs7OzswQkFDZiw4REFBQ0cscUVBQU9BOzs7OzswQkFDUiw4REFBQ0MsOEVBQWFBOzs7OzswQkFDZCw4REFBQ0csd0VBQVFBOzs7OzswQkFFWCw4REFBQ0Qsb0ZBQWtCQTs7Ozs7Ozs7Ozs7QUFNMUI7S0FyQk1HO0FBdUJOLCtEQUFlQSxRQUFRQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy9hcHAvcGFnZXMvSG9tZS9wYWdlLmpzeD84ZThhIl0sInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgSGVhZGVyTWlkZGxlIGZyb20gJ0AvYXBwL2NvbXBvbmVudHMvSGVhZGVyL0hlYWRlck1pZGRsZS9IZWFkZXJNaWRkbGUnXHJcbmltcG9ydCBIZWFkZXJUb3AgZnJvbSAnQC9hcHAvY29tcG9uZW50cy9IZWFkZXIvSGVhZGVyVG9wL0hlYWRlclRvcCdcclxuaW1wb3J0IE5hdmJhciBmcm9tICdAL2FwcC9jb21wb25lbnRzL0hlYWRlci9OYXZCYXIvTmF2YmFyJ1xyXG5pbXBvcnQgSGVyb1NlYyBmcm9tICdAL2FwcC9zZWN0aW9ucy9IZXJvc2VjL0hlcm9TZWMnXHJcbmltcG9ydCBGZWF0dXJlUHJvZHVjdHMgZnJvbSAnQC9hcHAvc2VjdGlvbnMvRmVhdHVyZWRQcm9kdWN0cy9Qcm9kdWN0cydcclxuaW1wb3J0IFByb2R1Y3RzVXBkYXRlIGZyb20gJ0AvYXBwL3NlY3Rpb25zL1Byb2R1Y3RzVXBkYXRlL1Byb2R1Y3RzVXBkYXRlJ1xyXG5cclxuaW1wb3J0IEhlcm9TZWN0aW9uIGZyb20gJ0AvYXBwL3NlY3Rpb25zL0hlcm8vSGVybydcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgUmV2aWV3cyBmcm9tICdAL2FwcC9zZWN0aW9ucy9SZXZpZXdzL1Jldmlld3MnXHJcbmltcG9ydCBCZXN0T2ZmZXJDYXJkIGZyb20gJ0AvYXBwL3NlY3Rpb25zL0Jlc3RPZmZlci9CZXN0T2ZmZXJDYXJkJ1xyXG5pbXBvcnQgQ2FyZCBmcm9tICdAL2FwcC9zZWN0aW9ucy9UaHJlZUNhcmQvQ2FyZCdcclxuaW1wb3J0IFRvcENhdGFnb3J5UHJvZHVjdCBmcm9tICdAL2FwcC9zZWN0aW9ucy9Ub3BDYXRhZ29yeS9DYXJvdXNlbENvbXBvbmVudCdcclxuaW1wb3J0IEZvbGxvd1VzIGZyb20gJ0AvYXBwL3NlY3Rpb25zL0ZvbGxvd1VzL0ZvbGxvd1VTJ1xyXG5pbXBvcnQgRm9vdGVyIGZyb20gJ0AvYXBwL2NvbXBvbmVudHMvRm9vdGVyL0Zvb3RlcidcclxuXHJcblxyXG5cclxuXHJcbmNvbnN0IEhvbWVQYWdlID0gKCkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICAgIHsvKiA8SGVhZGVyVG9wIC8+XHJcbiAgICAgICAgIDxIZWFkZXJNaWRkbGUgLz5cclxuICAgICAgICA8TmF2YmFyIC8+ICovfVxyXG4gICAgICAgICA8SGVyb1NlYyAvPlxyXG4gICAgICAgICBcclxuICAgICAgICAgXHJcbiAgICAgICAgIDxGZWF0dXJlUHJvZHVjdHMgLz5cclxuICAgICAgICAgPFByb2R1Y3RzVXBkYXRlIC8+XHJcbiAgICAgICAgIDxSZXZpZXdzIC8+XHJcbiAgICAgICAgIDxCZXN0T2ZmZXJDYXJkIC8+XHJcbiAgICAgICAgIDxGb2xsb3dVcyAvPlxyXG4gICAgICAgICB7LyogPENhcmQgLz4gKi99XHJcbiAgICAgICA8VG9wQ2F0YWdvcnlQcm9kdWN0IC8+XHJcbiAgICAgICB7LyogPEZvb3RlciAvPlxyXG4gICAgICAgICAgKi99XHJcbiAgICAgICBcclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSG9tZVBhZ2UiXSwibmFtZXMiOlsiSGVhZGVyTWlkZGxlIiwiSGVhZGVyVG9wIiwiTmF2YmFyIiwiSGVyb1NlYyIsIkZlYXR1cmVQcm9kdWN0cyIsIlByb2R1Y3RzVXBkYXRlIiwiSGVyb1NlY3Rpb24iLCJSZWFjdCIsIlJldmlld3MiLCJCZXN0T2ZmZXJDYXJkIiwiQ2FyZCIsIlRvcENhdGFnb3J5UHJvZHVjdCIsIkZvbGxvd1VzIiwiRm9vdGVyIiwiSG9tZVBhZ2UiLCJkaXYiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-pages-browser)/./src/app/pages/Home/page.jsx\n"));

/***/ })

});